# mb.extruder

__An open source jQuery component to easily build a top or left sliding panel.__

![mb.extruder](http://pupunzi.com/gitHubImg/mb.extruder.jpg)

## [go to the demo](http://pupunzi.com/#mb.components/mb.extruder/extruder.html)
## [go to the doc](http://wiki.github.com/pupunzi/jquery.mb.extruder/)
## [go to the blog](http://pupunzi.open-lab.com/mb-jquery-components/jquery-mb-extruder/)


[jquery.mb.components](http://pupunzi.com/), another way of thinking the web
